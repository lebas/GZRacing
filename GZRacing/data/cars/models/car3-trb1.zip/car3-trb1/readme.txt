Sports car model
--
Copyright © 2000  ViPeR (viper@mttestdriver.com) (model)
Copyright © 2002 Jean-Christophe Durieu (texture)
Copyright © 2006 Olaf Sassnick, Andrew Sumner (cockpit parts, mirrors)
Copyright © 2006 Bernhard Wymann (model and textures)

Copyleft: this work of art is free, you can redistribute
it and/or modify it according to terms of the Free Art license.
You will find a specimen of this license on the site
Copyleft Attitude http://artlibre.org as well as on other sites.
