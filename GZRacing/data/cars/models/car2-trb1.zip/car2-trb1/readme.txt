Sports car model

--
Copyright  2002 Eric Espie, Jean-Christophe Durieu
Copyright  2005 Olaf Sa�ick, Bernhard Wymann
Copyright  2007 Bernhard Wymann (totally reworked, renamed, based on old model)

Copyleft: this work of art is free, you can redistribute
it and/or modify it according to terms of the Free Art license.
You will find a specimen of this license on the site
Copyleft Attitude http://artlibre.org as well as on other sites.

