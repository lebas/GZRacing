Sports car model
--
Copyright © 2002 Eric Espie, Jean-Christophe Durieu (360-modena)
Copyright © 2006 Bernhard Wymann
Reused parts from porsche-gt3-rs Copyright © 2005 Olaf Saßnick, Bernhard Wymann

Copyleft: this work of art is free, you can redistribute
it and/or modify it according to terms of the Free Art license.
You will find a specimen of this license on the site
Copyleft Attitude http://artlibre.org as well as on other sites.

